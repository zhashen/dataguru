import numpy as np

from tttrade.datamodels import *


def ftr_sma(stock_ts, window):
    n = f'sma_{window}'
    if stock_ts.indicators.get(n) is None:
        stock_ts.indicators.update(ind_sma(stock_ts.prices, window))
    ttype = 'numeric'
    for k, i in enumerate(stock_ts.sel_ins_index):
        head = stock_ts.raw_Xs_index[i][1]
        feature = StockTSFeature(value=stock_ts.indicators[n][head], ttype=ttype)
        stock_ts.ftr_Xs[k].append(feature.value)
    stock_ts.ftr_types_Xs.append(ttype)
    stock_ts.ftr_names_Xs.append(n)
    return stock_ts


def ftr_sma_cross(stock_ts, long_window=15, short_window=5, thres=0.0005):
    n1 = f'sma_{short_window}'
    n2 = f'sma_{long_window}'
    if stock_ts.indicators.get(n1) is None:
        stock_ts.indicators.update(ind_sma(stock_ts.prices, short_window))
    if stock_ts.indicators.get(n2) is None:
        stock_ts.indicators.update(ind_sma(stock_ts.prices, long_window))

    ttype = 'ordinal'
    for k, i in enumerate(stock_ts.sel_ins_index):
        head = stock_ts.raw_Xs_index[i][1]
        short_avg = stock_ts.indicators[n1][head]
        long_avg = stock_ts.indicators[n2][head]
        r = (short_avg-long_avg)/long_avg    
        if r >= thres:
            feature = StockTSFeature(value=2, ttype=ttype)
        elif r <= -thres:
            feature = StockTSFeature(value=0, ttype=ttype)
        else:
            feature = StockTSFeature(value=1, ttype=ttype)
        stock_ts.ftr_Xs[k].append(feature.value)
    stock_ts.ftr_types_Xs.append(ttype)
    stock_ts.ftr_names_Xs.append(f'sma_cross_{short_window}_{long_window}')
    return stock_ts



# Indicators
def ind_sma(array, window):
    r = []
    for i in range(0, len(array)):
        r.append(np.mean(array[max(0, i+1-window):i+1]))
    return {f'sma_{window}': r}


def ind_ema(array, window):
    s = pd.Series(array)
    return {f'ema_{window}': list(s.ewm(span=window, adjust=False).mean().values)}


def ind_macd(array, short_window=12, long_window=26, signal_window=9):
    df = pd.DataFrame(array, columns=['Price'])
    df['ShortEMA'] = df['Price'].ewm(span=short_window, adjust=False).mean()
    df['LongEMA'] = df['Price'].ewm(span=long_window, adjust=False).mean()
    df['MACD'] = df['ShortEMA'] - df['LongEMA']
    df['Signal'] = df['MACD'].ewm(span=signal_window, adjust=False).mean()
    df['Histogram'] = df['MACD'] - df['Signal']
    return {
        'macd'        : df['MACD'].values.tolist(),
        'macd_signal' : df['Signal'].values.tolist(),
        'macd_hist'   : df['Histogram'].values.tolist(),
    }
