import pandas as pd

from tttrade import datamodels
from tttrade import features
from tttrade import timeseries


class StyBase:

    def set_stock_ts(self, stock_ts: datamodels.StockTSMinuteInDay):
        self.stock_ts = stock_ts

    def predict(self, stock_ts: datamodels.StockTSMinuteInDay, tick):
        pass

    def describe(self):
        return 'BaseStrategy()'

class StySimpleMA(StyBase):

    def __init__(self, short_window, long_window):
        self.short_window = short_window
        self.long_window = long_window

    def predict(self, stock_ts: datamodels.StockTSMinuteInDay, tick):
        tick += 1
        if tick < self.long_window:
            return 1
        short_avg = sum(stock_ts.prices[tick-self.short_window:tick]) / self.short_window
        long_avg = sum(stock_ts.prices[tick-self.long_window:tick]) / self.long_window
        if short_avg > long_avg:
            return 2
        else:
            return 0
    
    def describe(self):
        return f'SimpleMA(short_window={self.short_window}, long_window={self.long_window})'


class StyMACD(StyBase):

    def __init__(self, short_window=12, long_window=26, signal_window=9):
        self.short_window = short_window
        self.long_window = long_window
        self.signal_window = signal_window


    def predict(self, stock_ts: datamodels.StockTSMinuteInDay, tick):
        tick += 1
        if tick < self.long_window:
            return 1
        
        if self.stock_ts is None:
            df = pd.DataFrame(stock_ts.prices[:tick], columns=['Price'])
            df['ShortEMA'] = df['Price'].ewm(span=self.short_window, adjust=False).mean()
            df['LongEMA'] = df['Price'].ewm(span=self.long_window, adjust=False).mean()
            df['MACD'] = df['ShortEMA'] - df['LongEMA']
            df['Signal'] = df['MACD'].ewm(span=self.signal_window, adjust=False).mean()
            df['Histogram'] = df['MACD'] - df['Signal']
            # take the last row
            row = df.iloc[-1]
            macd = row['MACD']
            signal = row['Signal']
        else:  # compute MACD in advance in self.stock_ts
            if self.stock_ts.indicators.get('macd') is None:
                self.stock_ts.indicators.update(features.ind_macd(self.stock_ts.prices, self.short_window, self.long_window, self.signal_window))
            macd = self.stock_ts.indicators['macd'][tick-1]
            signal = self.stock_ts.indicators['macd_signal'][tick-1]
        if macd > signal and signal > 0:
            return 2
        elif macd < signal and signal < 0:
            return 0
        else:
            return 1
            
    
    def describe(self):
        return f'MACD(short_window={self.short_window}, long_window={self.long_window}, signal_window={self.signal_window})'


class StyBuyAtOpenSellAtClose(StyBase):

    def predict(self, stock_ts: datamodels.StockTSMinuteInDay, tick):
        if tick == 0:
            return 2
        elif tick == len(stock_ts.prices)-1:
            return 0
        else:
            return 1
    
    def describe(self):
        return 'BuyAtOpenSellAtClose()'
