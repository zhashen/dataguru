from typing import List, Optional, Tuple

import pandas as pd
from pydantic import BaseModel, constr, validator


class DictSymbol(BaseModel):
    symbol     : str
    name       : str
    country    : Optional[str] = ''
    start_year : Optional[str] = ''
    status     : Optional[str] = ''  # active, inactive
    sector     : Optional[str] = ''
    industry   : Optional[str] = ''
    exchange   : Optional[str] = ''
    type1      : Optional[str] = ''  # stock, index, etf, fx, etc


class StockPrice(BaseModel):
    symbol   : str
    ddate    : str
    open     : float
    high     : float
    low      : float
    close   : float
    volume   : float
    dividend : float
    split    : float


class StockFinancials(BaseModel):
    symbol                                                : str
    ddate                                                 : str   = ''
    type1                                                 : str   # annual, quarterly
    income_stmt_total_revenue                             : float = float('-inf')  # Total Revenue
    income_stmt_operating_revenue                         : float = float('-inf')  # Operating Revenue
    income_stmt_cost_of_revenue                           : float = float('-inf')  # Cost Of Revenue
    income_stmt_gross_profit                              : float = float('-inf')  # Gross Profit, Total Revenue - Cost Of Revenue
    income_stmt_operating_expense                         : float = float('-inf')  # Operating Expense
    income_stmt_operating_income                          : float = float('-inf')  # Operating Income, Gross Profit - Operating Expense
    income_stmt_net_non_operating_interest_income_expense : float = float('-inf')  # Net Non Operating Interest Income Expense
    income_stmt_interest_income_non_operating             : float = float('-inf')  # Interest Income Non Operating
    income_stmt_interest_expense_non_operating            : float = float('-inf')  # Interest Expense Non Operating
    income_stmt_other_income_expense                      : float = float('-inf')  # Other Income Expense
    income_stmt_pretax_income                             : float = float('-inf')  # Pretax Income
    income_stmt_tax_provision                             : float = float('-inf')  # Income Tax Provision
    income_stmt_net_income_common_stockholders            : float = float('-inf')  # Net Income Common Stockholders
    income_stmt_net_income                                : float = float('-inf')  # Net Income
    income_stmt_diluted_ni_availto_com_stockholders       : float = float('-inf')  # Diluted NI Avail to Com Stockholders
    income_stmt_basic_eps                                 : float = float('-inf')  # Basic EPS
    income_stmt_diluted_eps                               : float = float('-inf')  # Diluted EPS
    income_stmt_basic_average_shares                      : float = float('-inf')  # Basic Average Shares
    income_stmt_diluted_average_shares                    : float = float('-inf')  # Diluted Average Shares
    income_stmt_total_operating_income_as_reported        : float = float('-inf')  # Total Operating Income As Reported
    income_stmt_total_expenses                            : float = float('-inf')  # Total Expenses
    income_stmt_net_income_from_condiscon_ops             : float = float('-inf')  # Net Income From Continuing And Discontinued Ops
    income_stmt_normalized_income                         : float = float('-inf')  # Normalized Income
    income_stmt_interest_expense                          : float = float('-inf')  # Interest Expense
    income_stmt_net_interest_income                       : float = float('-inf')  # Net Interest Income
    income_stmt_ebit                                      : float = float('-inf')  # EBIT
    income_stmt_ebitda                                    : float = float('-inf')  # EBITDA
    income_stmt_reconciled_cost_of_revenue                : float = float('-inf')  # Reconciled Cost Of Revenue
    income_stmt_reconciled_depreciation                   : float = float('-inf')  # Reconciled Depreciation
    income_stmt_net_income_from_con_ops_net_min_interest  : float = float('-inf')  # Net Income From Con Ops Net Minority Interest
    income_stmt_total_unusual_items_excluding_goodwill    : float = float('-inf')  # Total Unusual Items Excluding Goodwill
    income_stmt_total_unusual_items                       : float = float('-inf')  # Total Unusual Items
    income_stmt_normalized_ebitda                         : float = float('-inf')  # Normalized EBITDA
    income_stmt_tax_rate_for_calcs                        : float = float('-inf')  # Tax Rate For Calcs
    income_stmt_tax_effect_of_unusual_items               : float = float('-inf')  # Tax Effect Of Unusual Items
    balance_sheet_total_assets                            : float = float('-inf')  # Total Assets
    balance_sheet_current_assets                          : float = float('-inf')  # Current Assets
    balance_sheet_cash_cash_equivalents_st_investment     : float = float('-inf')  # Cash, Cash Equivalents and Short-term Investments
    balance_sheet_cash_cash_equivalents                   : float = float('-inf')  # Cash, Cash Equivalents
    balance_sheet_cash                                    : float = float('-inf')  # Cash
    balance_sheet_cash_equivalents                        : float = float('-inf')  # Cash Equivalents
    balance_sheet_other_st_investments                    : float = float('-inf')  # Other Short-term Investments
    balance_sheet_receivables                             : float = float('-inf')  # Receivables
    balance_sheet_inventory                               : float = float('-inf')  # Inventory
    balance_sheet_other_current_assets                    : float = float('-inf')  # Other Current Assets
    balance_sheet_total_non_current_assets                : float = float('-inf')  # Total Non-current Assets
    balance_sheet_net_ppe                                 : float = float('-inf')  # Net PPE
    balance_sheet_gross_ppe                               : float = float('-inf')  # Gross PPE
    balance_sheet_accumulated_depreciation                : float = float('-inf')  # Accumulated Depreciation
    balance_sheet_goodwill_and_other_intangible_assets    : float = float('-inf')  # Goodwill and Other Intangible Assets
    balance_sheet_goodwill                                : float = float('-inf')  # Goodwill
    balance_sheet_intangible_assets                       : float = float('-inf')  # Intangible Assets
    balance_sheet_investments_and_advances                : float = float('-inf')  # Investments and Advances
    balance_sheet_other_non_current_assets                : float = float('-inf')  # Other Non-current Assets
    balance_sheet_total_liabilities_net_min_interests     : float = float('-inf')  # Total Liabilities
    balance_sheet_current_liabilities                     : float = float('-inf')  # Current Liabilities
    balance_sheet_payables_and_accrued_expenses           : float = float('-inf')  # Payables and Accrued Expenses
    balance_sheet_payables                                : float = float('-inf')  # Payables
    balance_sheet_pension_and_other_post_retire_benefits  : float = float('-inf')  # Pension And Other Post-retirement Benefits
    balance_sheet_current_debt_and_capital_lease_oblig    : float = float('-inf')  # Current Debt And Capital Lease Obligation
    balance_sheet_current_deferred_liabilities            : float = float('-inf')  # Current Deferred Liabilities
    balance_sheet_other_current_liabilities               : float = float('-inf')  # Other Current Liabilities
    balance_sheet_total_non_current_liabilities_net_min   : float = float('-inf')  # Total Non-current Liabilities
    balance_sheet_long_term_debt_and_capital_lease_oblig  : float = float('-inf')  # Long-term Debt And Capital Lease Obligation
    balance_sheet_long_term_debt                          : float = float('-inf')  # Long-term Debt
    balance_sheet_capital_lease_oblig                     : float = float('-inf')  # Capital Lease Obligations
    balance_sheet_non_current_deferred_liabilities        : float = float('-inf')  # Non-current Deferred Liabilities
    balance_sheet_trade_and_other_payables_non_current    : float = float('-inf')  # Trade And Other Payables Non-current
    balance_sheet_other_non_current_liabilities           : float = float('-inf')  # Other Non-current Liabilities
    balance_sheet_total_equity_gross_min_interest         : float = float('-inf')  # Total Equity
    balance_sheet_shareholders_equity                     : float = float('-inf')  # Shareholders Equity
    balance_sheet_capital_stock                           : float = float('-inf')  # Capital Stock
    balance_sheet_common_stock                            : float = float('-inf')  # Common Stock
    balance_sheet_retained_earnings                       : float = float('-inf')  # Retained Earnings
    balance_sheet_gains_losses_not_affecting_ret_earnings : float = float('-inf')  # Gains Losses Not Affecting Retained Earnings
    balance_sheet_total_capitalization                    : float = float('-inf')  # Total Capitalization
    balance_sheet_common_stock_equity                     : float = float('-inf')  # Common Stock Equity
    balance_sheet_capital_lease_obligations               : float = float('-inf')  # Capital Lease Obligations
    balance_sheet_net_tangible_assets                     : float = float('-inf')  # Net Tangible Assets
    balance_sheet_working_capital                          : float = float('-inf')  # Working Capital
    balance_sheet_invested_capital                        : float = float('-inf')  # Invested Capital
    balance_sheet_tangible_book_value                     : float = float('-inf')  # Tangible Book Value
    balance_sheet_total_debt                              : float = float('-inf')  # Total Debt
    balance_sheet_net_debt                                : float = float('-inf')  # Net Debt
    balance_sheet_share_issued                            : float = float('-inf')  # Share Issued
    cash_flow_operating_cash_flow                         : float = float('-inf')  # Operating Cash Flow
    cash_flow_investing_cash_flow                         : float = float('-inf')  # Investing Cash Flow
    cash_flow_financing_cash_flow                         : float = float('-inf')  # Financing Cash Flow
    cash_flow_end_cash_position                           : float = float('-inf')  # End Cash Position
    cash_flow_capital_expenditure                         : float = float('-inf')  # Capital Expenditure
    cash_flow_issuance_of_capital_stock                   : float = float('-inf')  # Issuance Of Capital Stock
    cash_flow_issuance_of_debt                            : float = float('-inf')  # Issuance Of Debt
    cash_flow_repayment_of_debt                           : float = float('-inf')  # Repayment Of Debt
    cash_flow_repurchase_of_capital_stock                 : float = float('-inf')  # Repurchase Of Capital Stock
    cash_flow_free_cash_flow                              : float = float('-inf')  # Free Cash Flow


class StockTSMinuteInDay(BaseModel):
    # time series at minute level in a day
    symbol        : str
    ddate         : constr(regex=r'^\d{4}-\d{2}-\d{2}$') # type: ignore
    times         : List[str] = []
    prices        : List[float] = []
    volumes       : List[float] = []
    amounts       : List[float] = []  # You may normalize prices and volumns. So you need a separate field for amounts.
    changes       : List[float] = []

    indicators    : dict = {}  # e.g. 'sma': [v1,...,vn], where n = len(prices)

    raw_Xs_index  : List[Tuple[int]] = []  # list of instances, each of which is represented by (tail pos, head pos)
    raw_Ys_index  : List[Tuple[int]] = []
    raw_Xs        : List[List[List[float]]] = [] # dim: (n, x_window, 4), the last dim is [price, volume, amount, change]
    raw_Ys        : List[List[List[float]]] = [] # dim: (n, y_window)
    agg_Xs        : List[dict]  = [] # For each instance, summarize metrics up to head time of the instance, e.g. max price, vol, etc

    cha_XYs       : List[List[float]] = [] # For each instance of (raw_X, raw_y), build a list of metrics to chracterise the window
    sel_ins_index : List[int] = [] # Selected instances after applying filters on cha_XYs

    ftr_Xs        : List[List[float]] = []  # features
    ftr_types_Xs  : List[str] = []    # 'numeric', 'ordinal', 'categorical'. This is to auto transform features to final_Xs
    ftr_names_Xs  : List[str] = []
    final_Xs      : List[List[float]] = []  # the final form of trainable/testable Xs
    label_Ys      : List[float] = []  # the final form of trainable/testable Ys

    para_x_window : int = 20
    para_y_window : int = 5
    para_step     : int = 1


class ListStockTSMinuteInDay(BaseModel):
    ts : List[StockTSMinuteInDay]


class StockTSFeature(BaseModel):
    value : float
    ttype : str   # 'numeric', 'ordinal', 'categorical'