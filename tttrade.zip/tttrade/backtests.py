from multiprocessing import Process, Manager

import numpy as np
import pandas as pd

from tttrade import timeseries
from tttrade import utility

db = utility.db


def trade_one_stock_in_day(symbol, ddate, strategy):
    stock_ts = timeseries.get_stock_price_minute(symbol, ddate)
    strategy.set_stock_ts(stock_ts)  
    n_ticks = len(stock_ts.prices)
    cash = 1000000
    pos = 0
    pos_vol = 0
    asset_ts = []
    pred_signals = []
    actu_signals = []
    cashes = []
    poss = []
    for tick in range(n_ticks):
        price = stock_ts.prices[tick]
        pos = price * pos_vol
        signal = strategy.predict(stock_ts, tick)  # 2: buy, 1: hold, 0: sell
        actu_signals.append(1) # default is hold
        if (pos == 0 and signal == 2):  
                pos_vol = int(cash / price)
                if pos_vol > 0:
                    pos = price * pos_vol
                    cash = cash - pos
                    actu_signals[-1] = 2
        elif (pos > 0 and signal == 0):
                cash = cash + pos
                pos = 0
                pos_vol = 0
                actu_signals[-1] = 0
        # Never hold through the night
        if tick == n_ticks - 1 and pos > 0:
            cash = cash + pos
            pos = 0
            pos_vol = 0
            actu_signals[-1] = 0
        asset_ts.append(cash+pos)
        pred_signals.append(signal)
    daily_return = (asset_ts[-1] - asset_ts[0])/asset_ts[0]
    daily_return = round(daily_return, 4)
    r = calc_trade_win_lose(asset_ts, actu_signals)
    return {
        'asset_ts'     : asset_ts, 
        'pred_signals' : pred_signals, 
        'actu_signals' : actu_signals,
        'daily_return' : daily_return,
        'n_trades'     : r['n_trades'],
        'n_wins'       : r['n_wins'],
    }


def trade_one_stock_in_period(symbol, start_date, end_date, strategy, risk_free_rate):
    date_list = [row['ddate'] for row in db['dict_trade_calendar'].find({'ddate': {'$gte': start_date, '$lte': end_date}}, {'_id': 0, 'ddate': 1})]
    result = []
    for ddate in date_list:
        try:
            r = trade_one_stock_in_day(symbol, ddate, strategy)
            daily_return = r['daily_return']*100
            result.append({'symbol': symbol, 'ddate': ddate, 'daily_return': daily_return, 'n_trades': r['n_trades'], 'n_wins': r['n_wins']})
        except:
            continue
    list_daily_returns = [row['daily_return']/100 for row in result]
    perf = calc_metrics_for_daily_return(list_daily_returns, risk_free_rate)
    df = pd.DataFrame(result)
    df = df[['symbol', 'n_trades', 'n_wins']].groupby(by=['symbol']).agg({'n_trades': 'sum', 'n_wins': 'sum'}).reset_index()
    # df = df.pivot(index='symbol', columns='ddate', values='daily_return').reset_index()
    df['Avg Daily Return(%)'] = perf['avg_daily_return']*100
    df['Annualized Return(%)'] = perf['annualized_return']*100
    df['Sharpe Ratio'] = perf['sharp_ratio']
    df['Max Draw Down(%)'] = perf['max_drawdown']
    df['Strategy'] = strategy.describe()
    df['Total Trades'] = df['n_trades']
    df['Avg Trades'] = df['n_trades'].apply(lambda x: round(x/len(date_list), 1))
    df['Wins'] = df['n_wins']
    df['Win Rate(%)'] = df[['n_trades', 'n_wins']].apply(lambda x: round(x[1]*100/x[0], 2), axis=1)
    # df = df[['symbol', 'Strategy', 'Avg Daily Return(%)', 'Annualized Return(%)', 'Max Draw Down(%)', 'Sharpe Ratio'] + date_list]
    df = df[['symbol', 'Strategy', 'Avg Daily Return(%)', 'Annualized Return(%)', 'Max Draw Down(%)', 'Sharpe Ratio', 
             'Total Trades', 'Avg Trades', 'Win Rate(%)']]
    return df


def _worker(symbol_sublist, shared_dict, start_date, end_date, strategy, risk_free_rate):
    for symbol in symbol_sublist:
        df = trade_one_stock_in_period(symbol, start_date, end_date, strategy, risk_free_rate)
        values = df.to_dict(orient='records')
        print(len(values))
        shared_dict[symbol] = values


def trade_stocks_in_period(symbol_list, start_date, end_date, strategy, risk_free_rate):
    
    def _divide_list(symbol_list, n_workers):
        avg_size = len(symbol_list) // n_workers
        remainder = len(symbol_list) % n_workers
        sublists = []
        start = 0
        for i in range(n_workers):
            # Distribute the remainder to the first 'remainder' sublists
            end = start + avg_size + (1 if i < remainder else 0)
            sublists.append(symbol_list[start:end])
            start = end
        return sublists


    manager = Manager()
    shared_dict = manager.dict()
    n_workers = 5
    symbol_sublists = _divide_list(symbol_list, n_workers)
    processes = []
    for symbol_sublist in symbol_sublists:
        p = Process(target=_worker, args=(symbol_sublist, shared_dict, start_date, end_date, strategy, risk_free_rate))
        processes.append(p)
        p.start()
    for p in processes:
        p.join()
    values = []
    for value in shared_dict.values():
        values.extend(value)
    df = pd.DataFrame(values)
    return df



def calc_metrics_for_daily_return(list_daily_returns, risk_free_rate):
    r = np.array(list_daily_returns)
    avg_daily_return = np.mean(r)
    trading_days = 252
    risk_free_rate_daily = risk_free_rate / 365
    excess_return_daily = avg_daily_return - risk_free_rate_daily
    daily_std_dev = np.std(r)
    sharpe_ratio_daily = excess_return_daily / daily_std_dev
    sharpe_ratio= sharpe_ratio_daily * np.sqrt(trading_days)

    annualized_return = (1+avg_daily_return)**trading_days - 1
    annualized_return = round(annualized_return, 4)
    max_drawdown = calc_max_drawdown(list_daily_returns)

    return {
         'avg_daily_return' : avg_daily_return,
         'annualized_return' : annualized_return,
         'sharp_ratio' : sharpe_ratio,
         'max_drawdown' : max_drawdown,
    }


def calc_max_drawdown(list_daily_returns):
    list_daily_returns = np.array(list_daily_returns)
    cumulative_returns = np.cumprod(1 + list_daily_returns) - 1
    running_max = np.maximum.accumulate(cumulative_returns)
    drawdowns = (running_max - cumulative_returns) / (1 + running_max)
    max_drawdown = np.max(drawdowns)
    return max_drawdown * 100


def calc_trade_win_lose(asset_ts, actu_signals):
    n_trades = 0
    n_wins = 0
    n_lose = 0
    tmp = -1
    for i, s in enumerate(actu_signals):
        if s == 2: # buy
            tmp = asset_ts[i]
        elif s == 0: # sell
            if tmp > 0:
                n_trades += 1
                if asset_ts[i] > tmp:
                    n_wins += 1
                else:
                    n_lose += 1
                tmp = -1
            else:
                raise ValueError("Can't sell before buy")
        else:
            pass
    return {'n_trades': n_trades, 'n_wins': n_wins}