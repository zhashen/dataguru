import MySQLdb
import pandas as pd
import pymongo

# Connect to MongoDB
mgo_client = pymongo.MongoClient('mongodb://localhost:27017/')
db = mgo_client['tintintrade2']

# Connect to MySQL
mysql_conn = MySQLdb.connect(
    host = 'localhost',
    user = 'root',
    password = 'titintrade123',
    database = 'tintintrade2',
)
mysql_cursor = mysql_conn.cursor()


def groupby_count(coll, by, count, filter={}):
    rows = [row for row in db[coll].find(filter, {count: 1, by: 1, '_id': 0})]
    df = pd.DataFrame(rows)
    df = df.groupby(by).count().sort_values(count, ascending=False)
    return df


def eq(value, type_var, default):
    try:
        return type_var(value)
    except:
        return default


def get_df_cell(df, row, col, default):
    try:
        return df.loc[row, col]
    except:
        return default

if __name__ == '__main__':
    pass