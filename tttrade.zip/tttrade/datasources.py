from datetime import datetime, timedelta

import pandas as pd
from pydantic import BaseModel

from tttrade.datamodels import StockTSMinuteInDay
from tttrade import utility as tutil

db = tutil.db


class BaseDataSource:
    
    def __init__(self):
        self.db = db

    def get_stock_price_minute(self, symbol, ddate, start='09:30:00', end='16:00:00') -> StockTSMinuteInDay:
        pass

    def _get_prev_trading_date(self, ddate):
        rows = [row for row in self.db['dict_trade_calendar'].find({}, {'_id': 0, 'year': 1, 'ddate': 1})]
        df = pd.DataFrame(rows)
        df = df.sort_values(by=['year', 'ddate'])
        # find the index of ddate where year, and ddate both match
        year = ddate[:4]
        idx = df[(df['year'] == year) & (df['ddate'] == ddate)].index[0]
        return df.iloc[idx]['ddate']
    


class SinaDataSource(BaseDataSource):

    def get_stock_price_minute(self, symbol, ddate, start='09:30:00', end='16:00:00') -> StockTSMinuteInDay:
        # Return a dataframe of stock time series
        # Example:
        #   symbol	ddate	    ttime	    price	    volume
        #	pltr	2024-05-20	09:35:00	21.3800	    316040.0
        #   pltr	2024-05-20	09:36:00	21.3099	    368985.0
        #   ...
        symbol = symbol.lower()
        rows = [row for row in db['raw_stock_price_minute_sina'].find({'symbol': symbol, 'ddate': ddate})]
        df = pd.DataFrame(rows)
        df = df[df.columns[1:]]
        df['ddate'] = df['ddate'].astype(str)
        df['ttime'] = df['ttime'].astype(str)
        date_range = pd.date_range(start=start, end=end, freq='1min').time
        df_time = pd.DataFrame(date_range, columns=['ttime'])
        df_time['ttime'] = df_time['ttime'].astype(str)
        df_time['ddate'] = ddate
        df_time['symbol'] = symbol
        df2 = pd.merge(df_time, df, how='left', on=['symbol', 'ddate', 'ttime'])
        df2 = df2[['symbol', 'ddate', 'ttime', 'price', 'volume']]
        df2['price'] = df2['price'].fillna(method='ffill')
        df2['price'] = df2['price'].fillna(method='bfill')
        df2['price'] = df2['price'].astype(float)
        df2['volume'] = df2['volume'].fillna(0)
        df2['volume'] = df2['volume'].astype(float)
        df2['amount'] = df2[['price', 'volume']].apply(lambda x: x[0]*x[1], axis=1)
        # Get previous trading day's price
        # prev_date = (datetime.strptime(ddate, '%Y-%m-%d') - timedelta(days=1)).strftime('%Y-%m-%d')
        prev_date = self._get_prev_trading_date(ddate)
        rows2 = [row for row in db['raw_stock_price_minute_sina'].find({'symbol': symbol, 'ddate': prev_date})]
        if len(rows2) == 0:
            raise Exception(f'No data for {symbol} on {prev_date}; cannot compute changes')
        prev_close = float(rows2[-1]['price'])
        df2['change'] = df2['price'].apply(lambda x: round((x-prev_close)/prev_close, 4))

        s = StockTSMinuteInDay(
            symbol  = symbol.upper(),
            ddate   = ddate,
            times   = df2['ttime'].values.tolist(),
            prices  = df2['price'].values.tolist(),
            volumes = df2['volume'].values.tolist(),
            amounts = df2['amount'].values.tolist(),
            changes = df2['change'].values.tolist()
        )
        return s
    

    def get_marketcap_for_one_stock(self, symbol):
        # Use the latest available info in database
        _filter = {'symbol': symbol.upper(), 'type1': 'annual'}
        _fields = {'_id': 0, 'symbol': 1, 'ddate': 1, 'income_stmt_basic_average_shares': 1}
        rows = [r for r in db['raw_stock_financials_yahoo'].find(_filter, _fields)]
        df1 = pd.DataFrame(rows)
        df1 = df1.sort_values(by='ddate', ascending=False)
        shares = df1.iloc[0]['income_stmt_basic_average_shares']

        query = [
            { '$match': { 'symbol': symbol.lower() } },
            { '$sort': { 'ddate': -1 } },
            { '$limit': 1 }
        ]
        a = [r for r in db['raw_stock_price_minute_sina'].aggregate(query)][0]
        lastest_date = a['ddate']
        query = [
            { '$match': { 'symbol': symbol.lower(), 'ddate': lastest_date } },
            { '$sort': { 'ttime': -1 } },
            { '$limit': 1 }
        ]
        b = [r for r in db['raw_stock_price_minute_sina'].aggregate(query)][0]
        price = float(b['price'])

        market_cap = price * shares
        return market_cap
    

    def get_liquidity_for_one_stock(self, symbol, start_date, end_date=None):
        # Compute average amount for the period (start_date, end_date)
        if end_date is None:
            end_date = datetime.strftime(datetime.now(), '%Y-%m-%d')
        _filter = {'symbol': symbol.lower(), 'ddate': {'$gte': start_date, '$lte': end_date}}
        _fields = {'_id': 0, 'ddate': 1, 'price': 1, 'volume': 1}
        rows = [r for r in db['raw_stock_price_minute_sina'].find(_filter, _fields)]
        df = pd.DataFrame(rows)
        df['amount'] = df[['price', 'volume']].apply(lambda x: float(x[0])*float(x[1]), axis=1)
        df = df.groupby('ddate').agg({'amount': 'sum'}).reset_index()
        avg_amount = df['amount'].mean()
        return avg_amount

    


