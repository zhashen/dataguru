from datetime import datetime, timedelta
import random

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from tttrade import datasources
from tttrade import datamodels
from tttrade import features
from tttrade import utility as tutil

# Config
db = tutil.db
data_source = datasources.SinaDataSource()


def get_stock_price_minute(symbol, ddate, start='09:30:00', end='16:00:00') -> datamodels.StockTSMinuteInDay:
    return data_source.get_stock_price_minute(symbol, ddate, start, end)


def build_raw_xy_for_one(symbol, ddate, start, end, x_window, y_window, step, normalized=False):
    stock_ts = data_source.get_stock_price_minute(symbol, ddate, start, end)
    if normalized is True:
        max_price = max(stock_ts.prices)
        stock_ts.prices = [p/max_price for p in stock_ts.prices]
        max_volume = max(stock_ts.volumes)
        stock_ts.volumes = [v/max_volume for v in stock_ts.volumes]
        max_amount = max(stock_ts.amounts)
        stock_ts.amounts = [a/max_amount for a in stock_ts.amounts]
    stock_ts.para_x_window = x_window
    stock_ts.para_y_window = y_window
    stock_ts.para_step = step
    x1 = stock_ts.prices
    x2 = stock_ts.volumes
    x3 = stock_ts.amounts
    x4 = stock_ts.changes
    ts = [(x1[i], x2[i], x3[i], x4[i]) for i in range(len(x1))]
    xs_index = []
    ys_index = []
    xs = []
    ys = []
    agg_xs = []
    for i in range(0, len(ts)-x_window-y_window, step):
        x = ts[i:i+x_window]
        y = ts[i+x_window:i+x_window+y_window]
        xs.append(x)
        ys.append(y)
        xs_index.append((i, i+x_window-1))
        ys_index.append((i+x_window, i+x_window+y_window-1))
        # metric up to this window, e.g. max, min, avg, vol
        upto_prices = [r[0] for r in ts[:i+x_window]]
        upto_volumes = [r[1] for r in ts[:i+x_window]]
        upto_amounts = [r[2] for r in ts[:i+x_window]]
        metrics = {
            'open_chg'  : stock_ts.changes[0],
            'min_price'  : min(upto_prices),
            'max_price'  : max(upto_prices),
            'avg_price'  : np.mean(upto_prices),
            'std_price'  : np.std(upto_prices),
            'min_volume' : min(upto_volumes),
            'max_volume' : max(upto_volumes),
            'avg_volume' : np.mean(upto_volumes),
            'std_volume' : np.std(upto_volumes),
            'min_amount' : min(upto_amounts),
            'max_amount' : max(upto_amounts),
            'avg_amount' : np.mean(upto_amounts),
            'std_amount' : np.std(upto_amounts),
        }
        agg_xs.append(metrics)
    stock_ts.raw_Xs_index = xs_index
    stock_ts.raw_Ys_index = ys_index
    stock_ts.raw_Xs = xs
    stock_ts.raw_Ys = ys
    stock_ts.agg_Xs = agg_xs
    # By default, select all instances
    stock_ts.sel_ins_index = list(range(len(xs)))
    return stock_ts



def plot_stock_ts_prices(stock_ts):
    plt.figure(figsize=(16, 4))
    plt.plot(stock_ts.times, stock_ts.prices)
    plt.title(f'{stock_ts.symbol} on {stock_ts.ddate}')
    # plt.grid()
    plt.show()


def plot_stock_ts_segment(stock_ts, k):
    # The k-th segment
    n = len(stock_ts.raw_Xs)
    x_ins = stock_ts.raw_Xs[k]
    y_ins = stock_ts.raw_Ys[k]
    xs = [item[0] for item in x_ins] + [y_ins[0][0]]
    pos_xs = range(k*stock_ts.para_step, k*stock_ts.para_step+stock_ts.para_x_window+1)

    ys = [item[0] for item in y_ins]
    pos_ys = range(k*stock_ts.para_step+stock_ts.para_x_window, k*stock_ts.para_step+stock_ts.para_x_window+stock_ts.para_y_window)

    plt.figure(figsize=(16, 4))
    plt.plot(stock_ts.prices, color='blue')
    plt.plot(pos_xs, xs, color='red')
    plt.plot(pos_ys, ys, color='green')
    plt.grid()
    plt.show()


def plot_stock_ts_trade(stock_ts, trade_signals):
    plt.figure(figsize=(16, 4))
    times = [i for i in range(len(stock_ts.prices))]
    plt.plot(times, stock_ts.prices)
    for i, signal in enumerate(trade_signals):
        if signal == 2:  # Buy signal
            plt.annotate('↑', (times[i], stock_ts.prices[i]),
                        textcoords="offset points", xytext=(0,-24),
                        ha='center', color='green', fontsize=24)
        elif signal == 0:  # Sell signal
            plt.annotate('↓', (times[i], stock_ts.prices[i]),
                        textcoords="offset points", xytext=(0,16),
                        ha='center', color='red', fontsize=24)
    plt.grid()
    plt.show()


def plot_stock_ts_indicator(stock_ts, indicators, twinx=False):
    plt.figure(figsize=(16, 4))
    plt.plot(stock_ts.prices, color='blue', label='Price')
    ax = plt.gca()
    ax2 = ax.twinx()
    # Prepare a list of colors for indicators
    start_color = [1.0, 0.0, 0.0] 
    def _adjust_color(color, increment):
        return [(channel + increment) % 1.0 for channel in color]
    colors = [start_color]
    increment = 0.2
    for _ in range(len(indicators)):
        new_color = _adjust_color(colors[-1], increment)
        colors.append(new_color)
    # End
    for i, n in enumerate(indicators):
        indicator = stock_ts.indicators[n]
        if twinx is False:
            plt.plot(indicator, color=colors[i], label=n)
        else:
            ax2.plot(indicator, color=colors[i], label=n)
    plt.legend()
    plt.grid()
    plt.show()


def get_market_cap_by_symbol(symbol, ddate):
    r = db['raw_stock_financials_yahoo'].find_one({'symbol': symbol.upper()}, {'_id': 0, 'symbol': 1, 'income_stmt_basic_average_shares': 1})
    if r is None:
        return None
    r2 = [item for item in db['raw_stock_price_minute_sina'].find({'symbol': symbol.lower(), 'ddate': ddate})]
    if len(r2) == 0:
        return None
    df = pd.DataFrame(r2)
    df = df.sort_values(by='ttime')
    price = df.iloc[-1]['price']
    shares = r['income_stmt_basic_average_shares']
    try:
        shares = float(shares)
        price = float(price)
    except:
        return None
    market_cap = price * shares
    return {'symbol': symbol.upper(), 'ddate': ddate, 'market_cap': market_cap}


def add_feature(stock_ts, feature_name, feature_kwargs):
    if len(stock_ts.ftr_Xs) == 0:
        stock_ts.ftr_Xs = [[] for _ in range(len(stock_ts.sel_ins_index))]
    func = getattr(features, feature_name)
    stock_ts = func(stock_ts, **feature_kwargs)
    return stock_ts


def build_labels_naive(stock_ts, x_recent, thres=0.0015):
    # See if avg y_window is greater than avg x_recent with a certain thres
    x_recent = min(x_recent, stock_ts.para_x_window)
    y_window = stock_ts.para_y_window
    label_Ys = []
    for i in stock_ts.sel_ins_index:
        x_ins = stock_ts.raw_Xs[i]
        y_ins = stock_ts.raw_Ys[i]
        avg_x_recent = np.mean([item[0] for item in x_ins[-x_recent:]])
        avg_y = np.mean([item[0] for item in y_ins])
        chg = (avg_y - avg_x_recent) / avg_x_recent
        if chg >= thres:
            label_Ys.append(2)
        elif chg <= -thres:
            label_Ys.append(0)
        else:
            label_Ys.append(1)
    stock_ts.label_Ys = label_Ys
    return stock_ts







